<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8" />
        <title>Admin Dashboard </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc."/>
        <meta name="author" content="Zoyothemes"/>
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('backend/assets/images/favicon.ico')); ?>">

        <!-- Quill css -->
        <link href="<?php echo e(asset('backend/assets/libs/quill/quill.core.js')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('backend/assets/libs/quill/quill.snow.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('backend/assets/libs/quill/quill.bubble.css')); ?>" rel="stylesheet" type="text/css" />

         <!-- Datatables css -->
         <link href="<?php echo e(asset('backend/assets/libs/datatables.net-bs5/css/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css" />
         <link href="<?php echo e(asset('backend/assets/libs/datatables.net-buttons-bs5/css/buttons.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css" />
         <link href="<?php echo e(asset('backend/assets/libs/datatables.net-keytable-bs5/css/keyTable.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css" />
         <link href="<?php echo e(asset('backend/assets/libs/datatables.net-responsive-bs5/css/responsive.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css" />
         <link href="<?php echo e(asset('backend/assets/libs/datatables.net-select-bs5/css/select.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- App css -->
        <link href="<?php echo e(asset('backend/assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="app-style" />
 
        <!-- Icons -->
        <link href="<?php echo e(asset('backend/assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" >

    </head>

    <!-- body start -->
    <body data-menu-color="light" data-sidebar="default">

        <!-- Begin page -->
        <div id="app-layout">


            <!-- Topbar Start -->
    <?php echo $__env->make('admin.body.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>        
            <!-- end Topbar -->

            <!-- Left Sidebar Start -->
    <?php echo $__env->make('admin.body.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>       
            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                
                <?php echo $__env->yieldContent('admin'); ?>
                <!-- content -->

                <!-- Footer Start -->
      <?php echo $__env->make('admin.body.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>    
                <!-- end Footer -->
                
            </div>
            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->

        <!-- Vendor -->
        <script src="<?php echo e(asset('backend/assets/libs/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/libs/simplebar/simplebar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/libs/node-waves/waves.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/libs/waypoints/lib/jquery.waypoints.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/libs/jquery.counterup/jquery.counterup.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/libs/feather-icons/feather.min.js')); ?>"></script>

        <!-- Apexcharts JS -->
        <script src="<?php echo e(asset('backend/assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>

        <!-- for basic area chart -->
        <script src="https://apexcharts.com/samples/assets/stock-prices.js"></script>

        <!-- Widgets Init Js -->
        <script src="<?php echo e(asset('backend/assets/js/pages/analytics-dashboard.init.js')); ?>"></script>

        <!-- App js-->
        <script src="<?php echo e(asset('backend/assets/js/app.js')); ?>"></script>

<!-- Datatables js -->
<script src="<?php echo e(asset('backend/assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>

<!-- dataTables.bootstrap5 -->
<script src="<?php echo e(asset('backend/assets/libs/datatables.net-bs5/js/dataTables.bootstrap5.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>

 <!-- Datatable Demo App Js -->
 <script src="<?php echo e(asset('backend/assets/js/pages/datatable.init.js')); ?>"></script>

  <!-- Quill Editor Js -->
  <script src="<?php echo e(asset('backend/assets/libs/quill/quill.core.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/libs/quill/quill.min.js')); ?>"></script>

  <!-- Quill Demo Js -->
  <script src="<?php echo e(asset('backend/assets/js/pages/quilljs.init.js')); ?>"></script>

 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script> 
 <script src="<?php echo e(asset('backend/assets/js/code.js')); ?>"></script>

 <script src="<?php echo e(asset('backend/assets/js/validate.min.js')); ?>"></script>

  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<script>
 <?php if(Session::has('message')): ?>
 var type = "<?php echo e(Session::get('alert-type','info')); ?>"
 switch(type){
    case 'info':
    toastr.info(" <?php echo e(Session::get('message')); ?> ");
    break;

    case 'success':
    toastr.success(" <?php echo e(Session::get('message')); ?> ");
    break;

    case 'warning':
    toastr.warning(" <?php echo e(Session::get('message')); ?> ");
    break;

    case 'error':
    toastr.error(" <?php echo e(Session::get('message')); ?> ");
    break; 
 }
 <?php endif; ?> 
</script>

    </body>
</html><?php /**PATH C:\Users\User\OneDrive\Desktop\laravel\basic\resources\views\admin\admin_master.blade.php ENDPATH**/ ?>