<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col fs-13 text-muted text-center">
                &copy; <script>document.write(new Date().getFullYear())</script> - Made with <span class="mdi mdi-heart text-danger"></span> by <a href="#!" class="text-reset fw-semibold">EasyLearningbd.com</a> 
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\Users\User\OneDrive\Desktop\laravel\basic\resources\views\admin\body\footer.blade.php ENDPATH**/ ?>